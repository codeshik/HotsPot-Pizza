package com.project.ppmtool.payload;







public class UserPojoResponse {
	 public UserPojoResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserPojoResponse(Long id, String username) {
		super();
		this.id = id;
		this.username = username;
		
	}

	private Long id;

	    private String username;
	    
	
	   
	  



		public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }


	   


	   

	 

}
