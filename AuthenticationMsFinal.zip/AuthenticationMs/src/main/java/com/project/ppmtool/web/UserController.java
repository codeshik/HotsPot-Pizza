package com.project.ppmtool.web;


import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.project.ppmtool.domain.User;
import com.project.ppmtool.payload.AuthResponse;
import com.project.ppmtool.payload.JWTLoginSucessReponse;
import com.project.ppmtool.payload.LoginRequest;
import com.project.ppmtool.payload.UserPojoResponse;
import com.project.ppmtool.repositories.UserRepository;
import com.project.ppmtool.security.JwtTokenProvider;

import com.project.ppmtool.services.MapValidationErrorService;
import com.project.ppmtool.services.UserService;
import com.project.ppmtool.validator.UserValidator;

import static com.project.ppmtool.security.SecurityConstants.TOKEN_PREFIX;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/users")
@CrossOrigin
public class UserController {
    
	private static Logger logger = LoggerFactory.getLogger(UserController.class);
	
    @Autowired
    private MapValidationErrorService mapValidationErrorService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserValidator userValidator;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private UserRepository userRepository;
    



 
    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest, BindingResult result){
        ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
        if(errorMap != null) return errorMap;

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = TOKEN_PREFIX +  jwtTokenProvider.generateToken(authentication);

        return ResponseEntity.ok(new JWTLoginSucessReponse(true, jwt));
    }
    

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody User user, BindingResult result){
        // Validate passwords match
        userValidator.validate(user,result);

        ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
        if(errorMap != null)return errorMap;

        User newUser = userService.saveUser(user);

        return  new ResponseEntity<User>(newUser, HttpStatus.CREATED);
    }
//    
//    @GetMapping(value = "/authorize")
//    public boolean authorizeTheRequest(
//			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) {
//    	System.out.println("inside authorize api");
//    	return tokenProvider.validateToken(requestTokenHeader);
//    }
// 
    
    @GetMapping("/validate")
	public AuthResponse getValidity(@RequestHeader("Authorization") String token) {
		logger.info("inside authenticationMs validate api--START");
		AuthResponse res = new AuthResponse();
		
		if (token == null) {
			res.setValid(false);
			logger.info("END - Null Token");
			
			return res;

			//return new ResponseEntity<>(res, HttpStatus.FORBIDDEN);
		} else {
			
			logger.info("Validate API(AuthenticationMs) is fired ");
			String token1 = token.substring(7);
			if (jwtTokenProvider.validateToken(token1)) {
				res.setUid(jwtTokenProvider.getUserIdFromJWT(token1));
				res.setValid(true);
				res.setName("admin");
			} else {
				res.setValid(false);
				logger.info("END - Token expired");
				return res;

				//return new ResponseEntity<>(res, HttpStatus.FORBIDDEN);

			}
		}
		logger.info("END - Token accepted");
		logger.info("validated auth response is:"+res.toString());
        
		return res;
		//return new ResponseEntity<>(res, HttpStatus.OK);

	}

    
    @GetMapping(value="/geUserFromUsername")
    public UserPojoResponse getUserFromUsername(@RequestHeader("Authorization")String TokenString, String userName) {
         logger.info("inside geUserFromUsername api(UserMs)");
         UserPojoResponse userPojoResponse = new UserPojoResponse();
         
         userPojoResponse.setId(jwtTokenProvider.getUserIdFromJWT(TokenString));
         userPojoResponse.setUsername(userName);
    	return userPojoResponse;
    	
    }
    
    @GetMapping(value="/getUsername")
    public String getUsername(@RequestHeader("Authorization")String Token) {
    	
    	String token1 = Token.substring(7);
    	Long id = jwtTokenProvider.getUserIdFromJWT(token1);
    	return jwtTokenProvider.getUsernameById(id);
    	
    }
    
//    
//    @GetMapping(value = "/getUserByUsername")
//	 public User getUserByUserName(String userName) {
//    	logger.info("inside getUserbyUsername api"+userName);
//    	return userRepository.findByUsername(userName);
//    	
//    }
    
    @GetMapping(value="/hello")
    public String sayHello() {
    	return "Hello";
    }
}
