package com.example.demo;

import com.example.demo.entity.Cart;
import com.example.demo.repository.CartRepository;
import com.example.demo.service.CartService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@RunWith(SpringRunner.class)
@WebMvcTest
public class CartControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    CartService cartService;

    @MockBean
    CartRepository cartRepository;

    private static ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testGetCart() throws Exception {
        Cart cart = new Cart();
        cart.setCartId(1);
        cart.setItemName("four chesse pizza");
        cart.setPrice(180);
        cart.setProductQuantity(1);
        cart.setUserId(23);

        List<Cart> allCart = new ArrayList<>();
        allCart.add(cart);

        Mockito.when(CartService.Cart()).thenReturn(allCart);
    }
}
