package com.genc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genc.entity.Feedback;
import com.genc.service.FeedbackService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class FeedbackController 
{
	@Autowired
	private FeedbackService fService;
	
	@GetMapping("/feedback/all")
	public List<Feedback> getAllFeedbacks(){
		return fService.getAllFeedback();
	}
	
	@PostMapping("/feedbacks")
	  public Feedback createFeedbacks(@RequestBody Feedback feedback)
	  {
		  return fService.createFeedback(feedback);
	  }
	  
	
  
}
