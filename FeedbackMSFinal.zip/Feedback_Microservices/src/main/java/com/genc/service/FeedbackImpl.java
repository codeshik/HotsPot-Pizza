package com.genc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genc.Repository.FeedbackRepository;
import com.genc.entity.Feedback;


@Service
public class FeedbackImpl implements FeedbackService {

	@Autowired
	private FeedbackRepository fDao;

	@Override
	public List<Feedback> getAllFeedback() {
		return fDao.findAll();
	}

	@Override
	public Feedback createFeedback(Feedback feedback) {
		return fDao.save(feedback);
	}

	
	

}