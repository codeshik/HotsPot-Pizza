package com.genc.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.genc.entity.Feedback;

@Service
public interface FeedbackService {


	
	List<Feedback> getAllFeedback();

	
	
	Feedback createFeedback(Feedback feedback);
 
}
