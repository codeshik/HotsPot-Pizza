package com.genc;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.genc.Repository.FeedbackRepository;
import com.genc.entity.Feedback;
import com.genc.service.FeedbackService;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import java.util.ArrayList;
import java.util.List;
@RunWith(SpringRunner.class)
@WebMvcTest
public class FeedbackControllerTest {

    @Autowired
    private MockMvc mvc;
    @MockBean
    FeedbackService feedbackService;
    @MockBean
    FeedbackRepository feedbackRepository;
    private static ObjectMapper mapper = new ObjectMapper();
    @Test
    public void testGetFeedback() throws Exception {
        Feedback feedback = new Feedback();
        feedback.setFeedbackId(1);
        feedback.setName("prasad");
        feedback.setEmail("prasad@gmail.com");
        feedback.setSubject("pizza");
        feedback.setMessage("very tasty");
        List<Feedback> allFeedback = new ArrayList<>();
        allFeedback.add(feedback);
        Mockito.when(feedbackService.getAllFeedback()).thenReturn(allFeedback);
        System.out.println("test method");
        mvc.perform(get("/api/v1/feedback/all").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].name", Matchers.equalTo(feedback.getName())));
    }
    @Test
    public void testSaveFeedback() throws Exception {
        Feedback feedback = new Feedback();
        feedback.setFeedbackId(1);
        feedback.setName("prasad");
        feedback.setEmail("prasad@gmail.com");
        feedback.setSubject("pizza");
        feedback.setMessage("very tasty");
        Mockito.when(feedbackService.createFeedback(ArgumentMatchers.any())).thenReturn(feedback);
        String json = mapper.writeValueAsString(feedback);
        mvc.perform(post("/api/v1/feedbacks").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8")
                .content(json).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }
}
